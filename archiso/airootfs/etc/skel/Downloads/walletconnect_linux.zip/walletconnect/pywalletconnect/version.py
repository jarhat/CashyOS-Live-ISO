"""pyWalletConnect version info."""

VERSION = "1.6.2"
